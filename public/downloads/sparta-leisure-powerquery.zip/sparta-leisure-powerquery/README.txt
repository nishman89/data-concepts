Sparta Leisure: Power Query practice data (2025)

members.json    every member who joined up to the end of 2025
visits/         one CSV of gym visits per site. Keep them together in this folder.
plans.csv       the membership plans
sites.xml       the six leisure centres

This is raw data. Some of it needs cleaning. Everyone in it is invented.
