Sparta Leisure: capstone data export, 1 January to 30 September 2026

members.csv     every member who joined up to 30 September 2026 (status as at 30 September 2026)
visits.csv      every gym check-in and check-out
bookings.json   every class booking, exported from the ClassBook system (bookings.csv is the same data as CSV)
sites.xml       the six leisure centres (sites.csv is the same data as CSV)
plans.csv       membership plans and their 2026 fees
classes.csv     the class menu
marketing.csv   marketing spend (£) by site and month, January 2025 to September 2026

This is a raw export. It has NOT been cleaned. Everyone in it is invented.
